# Dosa Ji — Hostinger Deployment Guide

## Folder Structure

```
dosaji-production/
├── dist/               Node.js server bundle (Express + API)
├── public/             Built React frontend (served as static files)
│   └── uploads/        User-uploaded images (auto-created, must be writable)
├── package.json        Start script
├── .env.example        Environment variable reference
└── DEPLOY.md           This file
```

## Step-by-Step Deployment on Hostinger (Node.js Hosting)

### 1. Upload files
- Upload the entire contents of this zip to your Hostinger Node.js app root
  (usually via File Manager or SFTP at `~/public_html` or your app directory)

### 2. Set up the database
- Create a **PostgreSQL** database in your Hostinger hPanel
- Copy the connection string — it will look like:
  `postgresql://username:password@localhost:5432/dbname`

### 3. Configure environment variables
- In hPanel → Node.js → your app → **Environment Variables**, add:

  | Key             | Value                                      |
  |---|---|
  | DATABASE_URL    | Your PostgreSQL connection string          |
  | SESSION_SECRET  | A long random string (32+ characters)      |
  | NODE_ENV        | production                                 |
  | PORT            | (leave blank — Hostinger sets this)        |

- Optionally add `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` for live payments

### 4. Run database migrations
- In Hostinger's Node.js terminal (or SSH), run:
  ```bash
  npx drizzle-kit push --config=<path>
  ```
  OR use the included SQL migration approach (see below)

### 5. Set the entry point
- In hPanel → Node.js → Application Settings:
  - **Entry point / Startup file:** `dist/index.mjs`
  - **Node.js version:** 18 or higher

### 6. Start the app
- Click **Start** / **Restart** in hPanel
- Visit your domain — the site should load

## Database Setup (without Drizzle CLI)

If you can't run Drizzle CLI, use the Hostinger phpMyAdmin / database panel to
run this SQL to create the tables:

```sql
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'customer',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS menu_items (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10,2) NOT NULL,
  category TEXT NOT NULL,
  image_url TEXT,
  is_available BOOLEAN NOT NULL DEFAULT true,
  sizes TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  items JSONB NOT NULL,
  status TEXT NOT NULL DEFAULT 'Placed',
  total NUMERIC(10,2) NOT NULL,
  delivery_address JSONB NOT NULL,
  coupon_code TEXT,
  razorpay_order_id TEXT,
  razorpay_payment_id TEXT,
  razorpay_signature TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TYPE discount_type AS ENUM ('percent', 'flat');

CREATE TABLE IF NOT EXISTS coupons (
  id SERIAL PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  discount_type discount_type NOT NULL,
  value NUMERIC(10,2) NOT NULL,
  min_order NUMERIC(10,2) NOT NULL DEFAULT 0,
  max_uses INTEGER NOT NULL DEFAULT 100,
  used_count INTEGER NOT NULL DEFAULT 0,
  expires_at TIMESTAMP,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS restaurant_settings (
  id SERIAL PRIMARY KEY,
  restaurant_name TEXT NOT NULL DEFAULT 'Dosa Ji',
  tagline TEXT NOT NULL DEFAULT 'Delicious Fast Food',
  address TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  delivery_charge NUMERIC(10,2) NOT NULL DEFAULT 40,
  gst_percent NUMERIC(5,2) NOT NULL DEFAULT 5,
  free_delivery_above NUMERIC(10,2) NOT NULL DEFAULT 0
);
```

Then create the default admin user (password: `admin123`):
```sql
INSERT INTO users (name, email, password, role)
VALUES ('Admin', 'admin@dosaji.com', '$2b$10$YourHashedPasswordHere', 'admin');
```

> For the real password hash, run the seed script or use the Register page and
> manually update the role to 'admin' via the database panel.

## Default Login Credentials (after seeding)

| Role       | Email                  | Password   |
|---|---|---|
| Admin      | admin@dosaji.com       | admin123   |
| Shopkeeper | shop@dosaji.com        | shop123    |
| Customer   | customer@dosaji.com    | customer123|

## Uploads Directory

The `public/uploads/` folder stores user-uploaded menu images.
Make sure this folder has **write permissions** (chmod 755 or 775).

## Support

Email: shreejanandan1@gmail.com | Phone: +91 95071 07204
